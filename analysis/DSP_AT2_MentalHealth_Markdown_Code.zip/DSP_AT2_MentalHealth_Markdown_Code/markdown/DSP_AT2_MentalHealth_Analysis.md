## Assignment DSP AT2

### Mental Health and Suicide Rate Analysis

**Team Member:**
<br> Hnin Pwint Tin (13738339)
<br> Irfan Sampe (13840121)
<br> Ki Ming Wong (13731738) 
<br> Mo Hussain (13524766)
<br> Priyanka Srinivasa (13684182)

We have selected Mental Health and Suicide rate dataset from Kaggle. Suicide is a global health issue. According to WHO (2020), “Close to 800 000 people die due to suicide every year, which is a global phenomenon and occurs throughout the lifespan”. The goal of our exploratory analysis is to find relationships in few key dimensions. Firstly, the economic condition of a country and the mental health care services it provides for the public has any correlation on suicide rates. Secondly, how the outcome differs in Sex types e.g. Male and Female. Finally, our analysis focuses on different age groups to contextualise the Suicide trends and also find associate factors relationships. 

It is worthwhile mentioning that Git will be the ultimate focus point of this assignment. Git’s social coding enable a software developer to easily share his activities and interest to other developers. Developers can thus track activities relevant to various projects. Rightly so, our group main focus would be to use Git extensively for different aspects of this project.


```python
# ========= Import the packages =========
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import math

# Importing Customised Common Data Reader Class
from common_lib.data_reader import SuicideDataReader, SuicideRawData, SuicideProcessedData
```

### 1. Worldwide Suicide Rate Distribution in 2016

Suicide occurs throughout the world. Its effects individuals of all nations, cultures, religions, genders and age ranges. This analysis aims to investigate to what extent how many countries are prevalent to suicidal death


```python
# ========= Getting Data =========

# Use common Data Reader Class to load data
data_reader = SuicideDataReader("../")

# Load Suicide Rate Tiday data done with Pivot Longer the rate of all age ranges
suicide_rate_data = data_reader.read_data(SuicideProcessedData.SUICIDE_RATES)
suicide_rate_data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>country</th>
      <th>sex</th>
      <th>80_above</th>
      <th>70to79</th>
      <th>60to69</th>
      <th>50to59</th>
      <th>40to49</th>
      <th>30to39</th>
      <th>20to29</th>
      <th>10to19</th>
      <th>all_age</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Afghanistan</td>
      <td>Both sexes</td>
      <td>42.0</td>
      <td>11.0</td>
      <td>5.5</td>
      <td>5.6</td>
      <td>6.6</td>
      <td>9.2</td>
      <td>10.2</td>
      <td>3.1</td>
      <td>93.2</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Afghanistan</td>
      <td>Male</td>
      <td>70.4</td>
      <td>20.9</td>
      <td>9.8</td>
      <td>9.3</td>
      <td>10.5</td>
      <td>15.1</td>
      <td>16.3</td>
      <td>4.8</td>
      <td>157.1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Afghanistan</td>
      <td>Female</td>
      <td>20.1</td>
      <td>2.3</td>
      <td>1.4</td>
      <td>1.6</td>
      <td>2.3</td>
      <td>2.7</td>
      <td>3.5</td>
      <td>1.2</td>
      <td>35.1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Albania</td>
      <td>Both sexes</td>
      <td>16.3</td>
      <td>8.3</td>
      <td>6.0</td>
      <td>7.8</td>
      <td>9.1</td>
      <td>6.1</td>
      <td>6.5</td>
      <td>5.0</td>
      <td>65.1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Albania</td>
      <td>Male</td>
      <td>23.2</td>
      <td>11.9</td>
      <td>8.1</td>
      <td>11.4</td>
      <td>13.5</td>
      <td>8.8</td>
      <td>6.3</td>
      <td>3.1</td>
      <td>86.3</td>
    </tr>
  </tbody>
</table>
</div>




```python
# This function serves to categorise (discretize)  the continuous variable value - 'suicide rate'
# Binning into 4 ranges of suicide rate
def suicide_rate_classification(rate):
    #rate = data[['all_age']]
    if (rate > 0 and rate <= 100):
        return "0-100"
    elif (rate > 100 and rate <=200):
        return "100-200"
    elif (rate >200 and rate <= 300):
        return "200-300"
    elif (rate > 300 and rate <= 400):
        return "300-400"
    else :
        return ">400"

# ====== Prepare Data for Plot (1) ======
# Filter the data for Both Sex only
suicide_rate_allage_bothsex = suicide_rate_data[suicide_rate_data["sex"] == "Both sexes"][["country", "sex", "all_age"]]
    
# Trigger the discretization function and store the result into the new column "suicide_rate_class"   
suicide_rate_allage_bothsex = suicide_rate_allage_bothsex.\
    assign(suicide_rate_class = lambda x: x["all_age"].map(lambda y: suicide_rate_classification(y)))

suicide_rate_allage_bothsex
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>country</th>
      <th>sex</th>
      <th>all_age</th>
      <th>suicide_rate_class</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Afghanistan</td>
      <td>Both sexes</td>
      <td>93.2</td>
      <td>0-100</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Albania</td>
      <td>Both sexes</td>
      <td>65.1</td>
      <td>0-100</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Algeria</td>
      <td>Both sexes</td>
      <td>38.8</td>
      <td>0-100</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Angola</td>
      <td>Both sexes</td>
      <td>165.8</td>
      <td>100-200</td>
    </tr>
    <tr>
      <th>12</th>
      <td>Antigua and Barbuda</td>
      <td>Both sexes</td>
      <td>8.1</td>
      <td>0-100</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>534</th>
      <td>Venezuela (Bolivarian Republic of)</td>
      <td>Both sexes</td>
      <td>43.3</td>
      <td>0-100</td>
    </tr>
    <tr>
      <th>537</th>
      <td>Viet Nam</td>
      <td>Both sexes</td>
      <td>89.4</td>
      <td>0-100</td>
    </tr>
    <tr>
      <th>540</th>
      <td>Yemen</td>
      <td>Both sexes</td>
      <td>92.1</td>
      <td>0-100</td>
    </tr>
    <tr>
      <th>543</th>
      <td>Zambia</td>
      <td>Both sexes</td>
      <td>204.9</td>
      <td>200-300</td>
    </tr>
    <tr>
      <th>546</th>
      <td>Zimbabwe</td>
      <td>Both sexes</td>
      <td>406.7</td>
      <td>&gt;400</td>
    </tr>
  </tbody>
</table>
<p>183 rows × 4 columns</p>
</div>




```python
#=========== Plotting (1)==============#

# The plot to visualise how many countries are in each range of suicide rate
sns.countplot(x="suicide_rate_class", data=suicide_rate_allage_bothsex, color="c")
plt.title("Suicide Rate Distribution in the Countries in 2016")
plt.ylabel("Number of countries")
plt.xlabel("Suicide Rate Ranges \n per 100,000 population")
plt.show()
```


    
![png](output_5_0.png)
    


The plots above illustrate the suicide rates in 4 ranges such as the rate between 0 and 100, from 100 to 200, from 200 to 300 and above 400 per 100,00 population in X-axis. The Y-axis shows the number of countries. 

The plot illustrates the general overview of the number of countries in each range of suicidal death rate. Out of 183 countries in the dataset, 145 countries have suicide rate between 0 to 200. The rest of the 38 countries have the rate 200 to beyond 400


```python
# ====== Prepare Data for Plot (2) ======

# Filter the data for male and female only 
suicide_rate_cat_by_sex = suicide_rate_data[suicide_rate_data['sex'] != 'Both sexes'][["country", "sex", "all_age"]]
# Trigger the discretization function to bin the suicide rate
suicide_rate_cat_by_sex = suicide_rate_cat_by_sex.assign(suicide_rate_class = lambda x: x["all_age"].map(lambda y: suicide_rate_classification(y)))
suicide_rate_cat_by_sex
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>country</th>
      <th>sex</th>
      <th>all_age</th>
      <th>suicide_rate_class</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>Afghanistan</td>
      <td>Male</td>
      <td>157.1</td>
      <td>100-200</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Afghanistan</td>
      <td>Female</td>
      <td>35.1</td>
      <td>0-100</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Albania</td>
      <td>Male</td>
      <td>86.3</td>
      <td>0-100</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Albania</td>
      <td>Female</td>
      <td>46.1</td>
      <td>0-100</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Algeria</td>
      <td>Male</td>
      <td>56.2</td>
      <td>0-100</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>542</th>
      <td>Yemen</td>
      <td>Female</td>
      <td>58.4</td>
      <td>0-100</td>
    </tr>
    <tr>
      <th>544</th>
      <td>Zambia</td>
      <td>Male</td>
      <td>343.6</td>
      <td>300-400</td>
    </tr>
    <tr>
      <th>545</th>
      <td>Zambia</td>
      <td>Female</td>
      <td>102.1</td>
      <td>100-200</td>
    </tr>
    <tr>
      <th>547</th>
      <td>Zimbabwe</td>
      <td>Male</td>
      <td>584.7</td>
      <td>&gt;400</td>
    </tr>
    <tr>
      <th>548</th>
      <td>Zimbabwe</td>
      <td>Female</td>
      <td>275.6</td>
      <td>200-300</td>
    </tr>
  </tbody>
</table>
<p>366 rows × 4 columns</p>
</div>




```python
#=========== Plotting (2)==============#

# The plot is to visualise and compare the variation of number of counties in Male-Female distribution of suicide rates 

rate_bin_list=["0-100", "100-200", "200-300", "300-400", ">400"]

##https://seaborn.pydata.org/tutorial/categorical.html
sns.catplot(x="suicide_rate_class", hue="sex", kind="count", data=suicide_rate_cat_by_sex, order=rate_bin_list)
plt.title("Suicide Rate Distribution in the Countries by Sex \n in 2016")
plt.ylabel("Number of countries")
plt.xlabel("Suicide Rate Ranges \n per 100,000 population")
plt.show()
```


    
![png](output_8_0.png)
    


The second plot visualises the comparison between male and female distribution within the suicide rate ranges. The female suicide rate is below 100 in majority of the 145 countries in the world as shown by outstanding orange bar. The suicide rate among males remain dominant in about 140 countries having the rate from 100 and beyond 400. It is quite alarming that around 80 countries over the world experience the male suicide rate over 200.


```python
# Load Suicide Rate Tiday data done with Pivot Longer the rate of all age ranges
suicide_rate_datatidy = data_reader.read_data(SuicideProcessedData.SUICIDE_RATES, tidy=True)
print(suicide_rate_datatidy.head(10))
```

           country         sex age_range  suicide_rate
    0  Afghanistan  Both sexes  80_above          42.0
    1  Afghanistan        Male  80_above          70.4
    2  Afghanistan      Female  80_above          20.1
    3      Albania  Both sexes  80_above          16.3
    4      Albania        Male  80_above          23.2
    5      Albania      Female  80_above          10.9
    6      Algeria  Both sexes  80_above           9.4
    7      Algeria        Male  80_above          12.7
    8      Algeria      Female  80_above           6.4
    9       Angola  Both sexes  80_above          63.5
    


```python
# ========= Plotting  =========
# Plotting is to visualise the suicide rate distribution in FacetGrid
sns.set_style("ticks")

age_plot = sns.FacetGrid(suicide_rate_datatidy, hue="sex", col="age_range", col_wrap=4)
age_plot.map(sns.barplot,"sex", "suicide_rate", order=["Male", "Female"])

age_plot.set_axis_labels("", "Suicide Rate")

# This is to adjust the axis and display the main title
# without it, seaborn's facet titles and the main title are overlapped
plt.subplots_adjust(top=0.85)
age_plot.fig.suptitle("Suicide Rate Distribution Analysis by Age \n in 2016 per 100.000 population")
plt.show()
```


    
![png](output_11_0.png)
    


The third plot attempts to visualise how suicide rate varies over different age groups in male and female. Across all the age groups, the death by suicide is the highest in the octogenarian. According to the World Health Organisation, the suicide rate in South Korea is the 10th highest in the world. One factor in its highest rate is the suicidal death among the elderly. 

Traditionally, children have been expected to care for their aging parents; however, because this system has mostly disappeared in the twenty-first century, many greying populations commit suicide, so they do not feel like they are a financial burden on their families. This reflects in our analysis and plots well. The first row in the third plot demonstrate the rate among 50-59 and senior citizens corporately higher than younger adults and teens.

In every age group, males are always in higher suicide rates than females. The working age group from 20 to 49 seem to be same in Male and Female with about 20 and 5 respectively


### 2. Top 10 countries with least suicide rates of Male and Female

The year 2020 has been a challenging year for most of us. With self-isolation, fear of losing jobs, and uncertainty creeping on us, it is difficult to remain balanced, and optimistic. All these factors can lead to mental illness, which might result in suicidal thoughts or the death itself. While analysing the countries with most suicide rates can give us an idea about the amount of help that can be offered for the people in those countries, analysing countries with least suicide rates might allow us to understand, and implement some of the strategies applied by the countries with the lowest suicide rates. The purpose of this analysis is to gain meaningful insights to take effective measures to prevent the cause. 

Below is the result of top 10 countries with least suicide rate for male, and female


```python
# ========= Prepare Data for plot (1) ========= #

# Filter for countries with female only 
suicide_rate_data_female = suicide_rate_data[suicide_rate_data["sex"] == "Female"]

# Sort the suicide rate of population in all ages inclusively
sort_female = suicide_rate_data_female.sort_values("all_age")
sort_female.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>country</th>
      <th>sex</th>
      <th>80_above</th>
      <th>70to79</th>
      <th>60to69</th>
      <th>50to59</th>
      <th>40to49</th>
      <th>30to39</th>
      <th>20to29</th>
      <th>10to19</th>
      <th>all_age</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>416</th>
      <td>Saint Vincent and the Grenadines</td>
      <td>Female</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.4</td>
      <td>1.4</td>
      <td>0.0</td>
      <td>3.0</td>
      <td>5.8</td>
    </tr>
    <tr>
      <th>32</th>
      <td>Bahamas</td>
      <td>Female</td>
      <td>2.4</td>
      <td>1.3</td>
      <td>0.9</td>
      <td>0.8</td>
      <td>0.5</td>
      <td>0.2</td>
      <td>0.4</td>
      <td>0.6</td>
      <td>7.1</td>
    </tr>
    <tr>
      <th>41</th>
      <td>Barbados</td>
      <td>Female</td>
      <td>0.0</td>
      <td>7.8</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>7.8</td>
    </tr>
    <tr>
      <th>515</th>
      <td>United Arab Emirates</td>
      <td>Female</td>
      <td>3.3</td>
      <td>1.4</td>
      <td>1.6</td>
      <td>1.4</td>
      <td>0.9</td>
      <td>0.8</td>
      <td>1.0</td>
      <td>0.3</td>
      <td>10.7</td>
    </tr>
    <tr>
      <th>248</th>
      <td>Jamaica</td>
      <td>Female</td>
      <td>4.3</td>
      <td>2.1</td>
      <td>1.2</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.3</td>
      <td>0.9</td>
      <td>12.8</td>
    </tr>
  </tbody>
</table>
</div>




```python

#=========== Plotting (1)==============#

Country = sort_female["country"].head(10) 
Total = sort_female["all_age"].head(10)
# Figure Size 
fig = plt.figure(figsize =(10, 7)) 
  
# Horizontal Bar Plot 
plt.barh(Country, Total) 
plt.title("Top 10 Countries with Least Female Suicide Rate in the world \n in 2016")
plt.ylabel("Countries")
plt.xlabel("Suicide Rate \n per 100,000 population")
plt.show()
```


    
![png](output_15_0.png)
    



```python
# ========= Prepare Data for Plot (2) ========= #

# Filter for countries with male only 
suicide_rate_data_male = suicide_rate_data[suicide_rate_data["sex"] == "Male"]
# Sort the suicide rate of population in all ages inclusively
sort_male = suicide_rate_data_male.sort_values("all_age")
sort_male.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>country</th>
      <th>sex</th>
      <th>80_above</th>
      <th>70to79</th>
      <th>60to69</th>
      <th>50to59</th>
      <th>40to49</th>
      <th>30to39</th>
      <th>20to29</th>
      <th>10to19</th>
      <th>all_age</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>13</th>
      <td>Antigua and Barbuda</td>
      <td>Male</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>265</th>
      <td>Kuwait</td>
      <td>Male</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>4.0</td>
      <td>3.7</td>
      <td>2.7</td>
      <td>3.3</td>
      <td>4.9</td>
      <td>1.3</td>
      <td>19.9</td>
    </tr>
    <tr>
      <th>40</th>
      <td>Barbados</td>
      <td>Male</td>
      <td>26.6</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.6</td>
      <td>0.9</td>
      <td>0.8</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>28.9</td>
    </tr>
    <tr>
      <th>199</th>
      <td>Grenada</td>
      <td>Male</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>29.4</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>29.4</td>
    </tr>
    <tr>
      <th>367</th>
      <td>Pakistan</td>
      <td>Male</td>
      <td>7.5</td>
      <td>4.0</td>
      <td>3.2</td>
      <td>3.2</td>
      <td>3.6</td>
      <td>4.5</td>
      <td>4.9</td>
      <td>2.1</td>
      <td>33.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
#=========== Plotting (2)==============#

country = sort_male["country"].head(10) 
total = sort_male["all_age"].head(10)
# Figure Size 
fig = plt.figure(figsize =(10, 7)) 
  
# Horizontal Bar Plot 
plt.barh(country, total) 
plt.title("Top 10 Countries with Least Male Suicide Rates in the world \n in 2016")
plt.ylabel("Countries")
plt.xlabel("Suicide Rate \n per 100,000 population") 
plt.show()
```


    
![png](output_17_0.png)
    


While there is a that there are good measures to prevent suicide in these countries, there can also be other factors such as, under reporting, and inappropriate data collection.  

### 3. Suicide rate comparison in different years


```python
# ========= Prepare Data for Plot ========= #
age_standardized = data_reader.read_data(SuicideRawData.AGE_STANDARDIZED)
age_standardized
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>country</th>
      <th>sex</th>
      <th>2016</th>
      <th>2015</th>
      <th>2010</th>
      <th>2000</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Afghanistan</td>
      <td>Both sexes</td>
      <td>6.4</td>
      <td>6.6</td>
      <td>7.4</td>
      <td>8.1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Afghanistan</td>
      <td>Male</td>
      <td>10.6</td>
      <td>10.9</td>
      <td>12.5</td>
      <td>14.3</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Afghanistan</td>
      <td>Female</td>
      <td>2.1</td>
      <td>2.1</td>
      <td>2.1</td>
      <td>1.7</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Albania</td>
      <td>Both sexes</td>
      <td>5.6</td>
      <td>5.3</td>
      <td>7.7</td>
      <td>5.8</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Albania</td>
      <td>Male</td>
      <td>7.0</td>
      <td>6.7</td>
      <td>9.5</td>
      <td>8.2</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>544</th>
      <td>Zambia</td>
      <td>Male</td>
      <td>17.5</td>
      <td>17.4</td>
      <td>17.9</td>
      <td>21.9</td>
    </tr>
    <tr>
      <th>545</th>
      <td>Zambia</td>
      <td>Female</td>
      <td>6.2</td>
      <td>6.1</td>
      <td>6.2</td>
      <td>7.5</td>
    </tr>
    <tr>
      <th>546</th>
      <td>Zimbabwe</td>
      <td>Both sexes</td>
      <td>19.1</td>
      <td>18.9</td>
      <td>20.6</td>
      <td>21.7</td>
    </tr>
    <tr>
      <th>547</th>
      <td>Zimbabwe</td>
      <td>Male</td>
      <td>29.1</td>
      <td>28.7</td>
      <td>32.3</td>
      <td>35.5</td>
    </tr>
    <tr>
      <th>548</th>
      <td>Zimbabwe</td>
      <td>Female</td>
      <td>11.1</td>
      <td>11.1</td>
      <td>11.1</td>
      <td>9.8</td>
    </tr>
  </tbody>
</table>
<p>549 rows × 6 columns</p>
</div>




```python
#=========== Plotting ==============#
sns.set_style("darkgrid")
f, axes = plt.subplots(2, 2, figsize=(15,15))
vis1 = sns.histplot(age_standardized["2016"],ax=axes[0,0], kde = True)
vis3 = sns.histplot(age_standardized["2015"],ax=axes[0,1], kde = True)
vis3 = sns.histplot(age_standardized["2010"],ax=axes[1,0], kde = True)
vis4 = sns.histplot(age_standardized["2000"],ax=axes[1,1], kde = True)
```


    
![png](output_21_0.png)
    


Our projects Age standardized suicides rates file has four years datasets. The above plots y-axis depicts the average suicide rate average per one hundred thousand people. The x-axis shows suicide rate trends in different numbers buckets. 

The lowest zero to highest 85. The average suicide rate year 2000, 2010, 2015 and 2016 are 12.16,10.54,9.93 and 9.79 respectively. The downwards trends clearly noticeable. On the Sex level comparison, Male suicide rate is 18.13 in year 2000 compare to 14.60 in the year 2016, a staggering 3.53 points drop. On the contrary, Female suicides rate in the year 2000 was 6.37 compare to 5.09 in the year 2016, 1.28 points drop in 16 years.

From the above analysis, it is quite evident that historically Females are less like to commit suicide. It also shows that the overall suicide rate on years-to-years is reducing hence seems to have positive impact.

### 4. The Relation between Income Inequality and Suicide Rate in Countries

Having a better understanding of the factors that could lead to suicide (risk factors) in a general population is pivotal in designing the prevention programs. One factor that has long been suspected as one of the strongly associated factors associated with suicide risk is a socioeconomic condition [Qin et al, 2003].

This analysis will explore the relationship between suicide rate with income inequality that measures the disparity of an individual’s income or wealth within a group of people or a nation. 

A GINI coefficient is one indicator of quantifying income inequality where the value ranges from 0 to 1. A GINI of zero (0) expresses perfect equality, e.g., everyone has the same amount of income, whereas one (1) means extreme inequality where only one person has all the wealth, and the rest have none.


```python
#load the socioeconomic indicators to a data.frame
#SuicideDataReader is a defined class/module to read the data from the data sources
socioeconomic = data_reader.read_data(SuicideRawData.SOCIOECONOMIC)
socioeconomic
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>country</th>
      <th>country_code</th>
      <th>gini_latest_year</th>
      <th>gini_coef</th>
      <th>poverty_latest_year</th>
      <th>poverty_199</th>
      <th>poverty_320</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Albania</td>
      <td>ALB</td>
      <td>2012</td>
      <td>29.0</td>
      <td>2017</td>
      <td>1.3</td>
      <td>8.2</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Algeria</td>
      <td>DZA</td>
      <td>2011</td>
      <td>27.6</td>
      <td>2011</td>
      <td>0.4</td>
      <td>3.7</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Angola</td>
      <td>AGO</td>
      <td>2008</td>
      <td>42.7</td>
      <td>2018</td>
      <td>51.8</td>
      <td>73.2</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Argentina</td>
      <td>ARG</td>
      <td>2014</td>
      <td>42.7</td>
      <td>2018</td>
      <td>1.3</td>
      <td>3.9</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Armenia</td>
      <td>ARM</td>
      <td>2015</td>
      <td>32.4</td>
      <td>2018</td>
      <td>1.4</td>
      <td>9.4</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>138</th>
      <td>Uzbekistan</td>
      <td>UZB</td>
      <td>2003</td>
      <td>35.3</td>
      <td>2003</td>
      <td>61.6</td>
      <td>86.2</td>
    </tr>
    <tr>
      <th>139</th>
      <td>Vanuatu</td>
      <td>VUT</td>
      <td>2010</td>
      <td>37.3</td>
      <td>2010</td>
      <td>13.2</td>
      <td>39.4</td>
    </tr>
    <tr>
      <th>140</th>
      <td>Vietnam</td>
      <td>VNM</td>
      <td>2014</td>
      <td>34.8</td>
      <td>2018</td>
      <td>1.9</td>
      <td>6.8</td>
    </tr>
    <tr>
      <th>141</th>
      <td>Zambia</td>
      <td>ZMB</td>
      <td>2015</td>
      <td>57.1</td>
      <td>2015</td>
      <td>58.7</td>
      <td>75.4</td>
    </tr>
    <tr>
      <th>142</th>
      <td>Zimbabwe</td>
      <td>ZWE</td>
      <td>2011</td>
      <td>43.2</td>
      <td>2017</td>
      <td>33.9</td>
      <td>61.0</td>
    </tr>
  </tbody>
</table>
<p>143 rows × 7 columns</p>
</div>




```python
#load the suicide rate to a data.frame
#SuicideDataReader is a defined class/module to read the data from the data sources
suiciderate = data_reader.read_data(SuicideRawData.SUICIDE_RATES, tidy = True)

#select "both sexes" only as no need to analyze by sex at the moment
suiciderate_bothsexes = suiciderate[suiciderate["sex"] == "Both sexes"]

#calculate the total number of suicide for all ages
suiciderate_bothsexes_allages = suiciderate_bothsexes.groupby("country", as_index = False)["suicide_rate"].sum()
suiciderate_bothsexes_allages
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>country</th>
      <th>suicide_rate</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Afghanistan</td>
      <td>93.2</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Albania</td>
      <td>65.1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Algeria</td>
      <td>38.8</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Angola</td>
      <td>165.8</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Antigua and Barbuda</td>
      <td>8.1</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>178</th>
      <td>Venezuela (Bolivarian Republic of)</td>
      <td>43.3</td>
    </tr>
    <tr>
      <th>179</th>
      <td>Viet Nam</td>
      <td>89.4</td>
    </tr>
    <tr>
      <th>180</th>
      <td>Yemen</td>
      <td>92.1</td>
    </tr>
    <tr>
      <th>181</th>
      <td>Zambia</td>
      <td>204.9</td>
    </tr>
    <tr>
      <th>182</th>
      <td>Zimbabwe</td>
      <td>406.7</td>
    </tr>
  </tbody>
</table>
<p>183 rows × 2 columns</p>
</div>




```python
#join both data frame for plotting purposes
suiciderate_socioeconomic = suiciderate_bothsexes_allages.merge(socioeconomic, on="country")

#classify GINI index into Low, High, and Severe 
#(based on classification from WorldBank: ...)
def gini_classification(gini):
    '''Classify the countries based on GINI coefficient that represent the severity of inequality in a particular country
    
       Parameter:
           gini (decimal) : gini coefficient
        
       Return:
           country classification that comprise of low, high, and severe inequality
    '''
    if (gini < 40):
        return "Low Inequality"
    elif (gini >= 40 and gini < 50):
        return "High Inequality"
    else:
        return "Severe Inequality"
    
suiciderate_socioeconomic = suiciderate_socioeconomic.\
    assign(gini_class = lambda x: x["gini_coef"].map(lambda y: gini_classification(y)))

suiciderate_socioeconomic
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>country</th>
      <th>suicide_rate</th>
      <th>country_code</th>
      <th>gini_latest_year</th>
      <th>gini_coef</th>
      <th>poverty_latest_year</th>
      <th>poverty_199</th>
      <th>poverty_320</th>
      <th>gini_class</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Albania</td>
      <td>65.1</td>
      <td>ALB</td>
      <td>2012</td>
      <td>29.0</td>
      <td>2017</td>
      <td>1.3</td>
      <td>8.2</td>
      <td>Low Inequality</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Algeria</td>
      <td>38.8</td>
      <td>DZA</td>
      <td>2011</td>
      <td>27.6</td>
      <td>2011</td>
      <td>0.4</td>
      <td>3.7</td>
      <td>Low Inequality</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Angola</td>
      <td>165.8</td>
      <td>AGO</td>
      <td>2008</td>
      <td>42.7</td>
      <td>2018</td>
      <td>51.8</td>
      <td>73.2</td>
      <td>High Inequality</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Argentina</td>
      <td>91.4</td>
      <td>ARG</td>
      <td>2014</td>
      <td>42.7</td>
      <td>2018</td>
      <td>1.3</td>
      <td>3.9</td>
      <td>High Inequality</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Armenia</td>
      <td>84.9</td>
      <td>ARM</td>
      <td>2015</td>
      <td>32.4</td>
      <td>2018</td>
      <td>1.4</td>
      <td>9.4</td>
      <td>Low Inequality</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>128</th>
      <td>Uruguay</td>
      <td>191.0</td>
      <td>URY</td>
      <td>2015</td>
      <td>41.7</td>
      <td>2018</td>
      <td>0.1</td>
      <td>0.4</td>
      <td>High Inequality</td>
    </tr>
    <tr>
      <th>129</th>
      <td>Uzbekistan</td>
      <td>64.6</td>
      <td>UZB</td>
      <td>2003</td>
      <td>35.3</td>
      <td>2003</td>
      <td>61.6</td>
      <td>86.2</td>
      <td>Low Inequality</td>
    </tr>
    <tr>
      <th>130</th>
      <td>Vanuatu</td>
      <td>78.8</td>
      <td>VUT</td>
      <td>2010</td>
      <td>37.3</td>
      <td>2010</td>
      <td>13.2</td>
      <td>39.4</td>
      <td>Low Inequality</td>
    </tr>
    <tr>
      <th>131</th>
      <td>Zambia</td>
      <td>204.9</td>
      <td>ZMB</td>
      <td>2015</td>
      <td>57.1</td>
      <td>2015</td>
      <td>58.7</td>
      <td>75.4</td>
      <td>Severe Inequality</td>
    </tr>
    <tr>
      <th>132</th>
      <td>Zimbabwe</td>
      <td>406.7</td>
      <td>ZWE</td>
      <td>2011</td>
      <td>43.2</td>
      <td>2017</td>
      <td>33.9</td>
      <td>61.0</td>
      <td>High Inequality</td>
    </tr>
  </tbody>
</table>
<p>133 rows × 9 columns</p>
</div>




```python
#plotting
sns.set_theme(style="white")

#plot suicide rate with GINI coefficient
sns.boxplot(data = suiciderate_socioeconomic, 
            x = "gini_class", 
            y = "suicide_rate", 
            order = ["Severe Inequality","High Inequality","Low Inequality"],
            showmeans = True,
            meanprops = {"markerfacecolor":"red", "markeredgecolor":"white"})
plt.title("Suicide Rate and GINI Coefficient \n Year: 2016")
plt.xlabel("GINI Classification")
plt.ylabel("Suicide Rate (per 100.000 population)")

plt.show
```




    <function matplotlib.pyplot.show(close=None, block=None)>




    
![png](output_27_1.png)
    


The plot above illustrates that the average number of suicides in countries with severe income inequality is higher than the other countries with a higher GINI coefficient (low or high inequality). There is an indication that the risk of suicide increases when the income gap in society is wider. Reducing income inequality might curb the risk of people in a society to commit suicide

### 5. Association between available of facilities in mental health care sectors and suicide rates in countries

This purpose of this analysis was finding out any relationship between suicide rate and mental health care facilities. 


```python
# ========= Getting Data =========

suicide_rates_dataframe = data_reader.read_data(SuicideProcessedData.SUICIDE_RATES)
print(suicide_rates_dataframe)

country_facilities_dataframe = data_reader.read_data(SuicideProcessedData.FACILITIES)
print(country_facilities_dataframe)

gini_coef_dataframe = data_reader.read_data(SuicideRawData.SOCIOECONOMIC)
print(gini_coef_dataframe)

# define constant variable
ALL_AGE_RANGES = ["all_age", "80_above", "70to79", "60to69", "50to59", "40to49", "30to39", "20to29", "10to19"]
ALL_FACILITIES = ["mental_hospitals", "health_units", "outpatient_facilities", "day_treatment", "residential_facilities"]
ALL_SEX = suicide_rates_dataframe["sex"].unique()
COLOR_FOR_SEX = {
    "Male" : "#0000AA",
    "Female" : "#AA0000",
    "Both sexes" : "#00AA00"
}
DISPLAY_NAME_FOR_FACILITIES = {
    "mental_hospitals" : "Mental Hospitals",
    "health_units" : "Health Units",
    "outpatient_facilities" : "Outpatient Facilities",
    "day_treatment" : "Day Treatment",
    "residential_facilities" : "Residential Facilities"
}
```

             country         sex  80_above  70to79  60to69  50to59  40to49  \
    0    Afghanistan  Both sexes      42.0    11.0     5.5     5.6     6.6   
    1    Afghanistan        Male      70.4    20.9     9.8     9.3    10.5   
    2    Afghanistan      Female      20.1     2.3     1.4     1.6     2.3   
    3        Albania  Both sexes      16.3     8.3     6.0     7.8     9.1   
    4        Albania        Male      23.2    11.9     8.1    11.4    13.5   
    ..           ...         ...       ...     ...     ...     ...     ...   
    544       Zambia        Male     152.1    79.0    38.7    27.3    17.0   
    545       Zambia      Female      31.2    26.4    16.0    11.2     6.9   
    546     Zimbabwe  Both sexes     205.7    81.5    41.3    29.4    19.2   
    547     Zimbabwe        Male     285.0   111.5    62.8    47.0    30.1   
    548     Zimbabwe      Female     152.4    59.4    26.4    16.0     9.4   
    
         30to39  20to29  10to19  all_age  
    0       9.2    10.2     3.1     93.2  
    1      15.1    16.3     4.8    157.1  
    2       2.7     3.5     1.2     35.1  
    3       6.1     6.5     5.0     65.1  
    4       8.8     6.3     3.1     86.3  
    ..      ...     ...     ...      ...  
    544    13.3    12.3     3.9    343.6  
    545     4.6     4.2     1.6    102.1  
    546    13.7    11.3     4.6    406.7  
    547    22.8    19.1     6.4    584.7  
    548     5.5     3.8     2.7    275.6  
    
    [549 rows x 11 columns]
                     country  year  mental_hospitals  health_units  \
    0            Afghanistan  2016             0.003         0.012   
    1                Albania  2016             0.068         0.068   
    2                Algeria  2016             0.048         0.068   
    3                 Angola  2016             0.011           NaN   
    4    Antigua and Barbuda  2016             1.001           NaN   
    ..                   ...   ...               ...           ...   
    107              Vanuatu  2016               NaN         0.756   
    108             Viet Nam  2016             0.043         0.017   
    109                Yemen  2016             0.033         0.026   
    110               Zambia  2016             0.062         0.062   
    111             Zimbabwe  2016             0.025         0.025   
    
         outpatient_facilities  day_treatment  residential_facilities  
    0                    0.006            NaN                     NaN  
    1                    0.410            NaN                   0.445  
    2                    0.048            NaN                     NaN  
    3                      NaN            NaN                   0.014  
    4                      NaN            NaN                     NaN  
    ..                     ...            ...                     ...  
    107                  2.645            NaN                     NaN  
    108                  0.009            NaN                     NaN  
    109                  0.063            NaN                     NaN  
    110                  0.205            NaN                   0.019  
    111                  0.057          0.006                   0.051  
    
    [112 rows x 7 columns]
            country country_code  gini_latest_year  gini_coef  \
    0       Albania          ALB              2012       29.0   
    1       Algeria          DZA              2011       27.6   
    2        Angola          AGO              2008       42.7   
    3     Argentina          ARG              2014       42.7   
    4       Armenia          ARM              2015       32.4   
    ..          ...          ...               ...        ...   
    138  Uzbekistan          UZB              2003       35.3   
    139     Vanuatu          VUT              2010       37.3   
    140     Vietnam          VNM              2014       34.8   
    141      Zambia          ZMB              2015       57.1   
    142    Zimbabwe          ZWE              2011       43.2   
    
         poverty_latest_year  poverty_199  poverty_320  
    0                   2017          1.3          8.2  
    1                   2011          0.4          3.7  
    2                   2018         51.8         73.2  
    3                   2018          1.3          3.9  
    4                   2018          1.4          9.4  
    ..                   ...          ...          ...  
    138                 2003         61.6         86.2  
    139                 2010         13.2         39.4  
    140                 2018          1.9          6.8  
    141                 2015         58.7         75.4  
    142                 2017         33.9         61.0  
    
    [143 rows x 7 columns]
    


```python
# ========= Prepare Data =========
# join country facilities and gini coef to suicde rate data
suicide_rates_facilities_dataframe = suicide_rates_dataframe.merge(country_facilities_dataframe, how="left", left_on="country", right_on="country")

suicide_rates_facilities_dataframe = suicide_rates_facilities_dataframe.merge(gini_coef_dataframe, how="left", left_on="country", right_on="country")

suicide_rates_facilities_dataframe["hos_out_ratio"] = suicide_rates_facilities_dataframe["outpatient_facilities"] / suicide_rates_facilities_dataframe["mental_hospitals"]

# distribution of suicide rate of all countries
for facility in ALL_FACILITIES:
    suicide_rates_facilities_dataframe["{0}_cat".format(facility)] = pd.qcut(suicide_rates_facilities_dataframe[facility], 
                                                                     q = 10, 
                                                                     labels = False, 
                                                                     precision = 0)


suicide_rates_facilities_both_sexes_dataframe = suicide_rates_facilities_dataframe[suicide_rates_facilities_dataframe["sex"] == "Both sexes"]

# Sorting and pick the first 5
# top_five_youth_suicide_rates_dataframe = suicide_rates_facilities_dataframe.sort_values(by=["10to19"], ascending=False).head(5)

# # print the results
# top_five_youth_suicide_rates_dataframe
```


```python


for sex in ALL_SEX:
    sex_color = COLOR_FOR_SEX[sex]
    for age_range in ALL_AGE_RANGES:
        plt.figure(figsize=(20,10))
        fig, axs = plt.subplots(nrows=2, ncols=3, constrained_layout=True)
        fig.figsize=(20,10)
        facilities_index = 0	# use for control the location of the plot
        for facility in ALL_FACILITIES:
            x_index = math.floor(facilities_index / 3)
            y_index = facilities_index % 3
            subplot = axs[x_index, y_index]
            subplot.scatter(x = suicide_rates_facilities_both_sexes_dataframe[age_range], 
                            y = suicide_rates_facilities_both_sexes_dataframe[facility], 
                            color = sex_color, 
                            s = 5)
            subplot.set_title("{0}".format(facility))
            #subplot.xlabel("{0} {1} suicide Rate (%)".format(sex, age_range))
            #subplot.ylabel("{0}".format(facility))
            plt.suptitle("{0} {1} vs different facilities".format(sex, age_range))
            facilities_index = facilities_index + 1
        axs[1, 2].axis('off')  
        plt.show()
```


    <Figure size 1440x720 with 0 Axes>



    
![png](output_32_1.png)
    



    <Figure size 1440x720 with 0 Axes>



    
![png](output_32_3.png)
    



    <Figure size 1440x720 with 0 Axes>



    
![png](output_32_5.png)
    



    <Figure size 1440x720 with 0 Axes>



    
![png](output_32_7.png)
    



    <Figure size 1440x720 with 0 Axes>



    
![png](output_32_9.png)
    



    <Figure size 1440x720 with 0 Axes>



    
![png](output_32_11.png)
    



    <Figure size 1440x720 with 0 Axes>



    
![png](output_32_13.png)
    



    <Figure size 1440x720 with 0 Axes>



    
![png](output_32_15.png)
    



    <Figure size 1440x720 with 0 Axes>



    
![png](output_32_17.png)
    



    <Figure size 1440x720 with 0 Axes>



    
![png](output_32_19.png)
    



    <Figure size 1440x720 with 0 Axes>



    
![png](output_32_21.png)
    



    <Figure size 1440x720 with 0 Axes>



    
![png](output_32_23.png)
    



    <Figure size 1440x720 with 0 Axes>



    
![png](output_32_25.png)
    



    <Figure size 1440x720 with 0 Axes>



    
![png](output_32_27.png)
    



    <Figure size 1440x720 with 0 Axes>



    
![png](output_32_29.png)
    



    <Figure size 1440x720 with 0 Axes>



    
![png](output_32_31.png)
    



    <Figure size 1440x720 with 0 Axes>



    
![png](output_32_33.png)
    



    <Figure size 1440x720 with 0 Axes>



    
![png](output_32_35.png)
    



    <Figure size 1440x720 with 0 Axes>



    
![png](output_32_37.png)
    



    <Figure size 1440x720 with 0 Axes>



    
![png](output_32_39.png)
    



    <Figure size 1440x720 with 0 Axes>



    
![png](output_32_41.png)
    



    <Figure size 1440x720 with 0 Axes>



    
![png](output_32_43.png)
    



    <Figure size 1440x720 with 0 Axes>



    
![png](output_32_45.png)
    



    <Figure size 1440x720 with 0 Axes>



    
![png](output_32_47.png)
    



    <Figure size 1440x720 with 0 Axes>



    
![png](output_32_49.png)
    



    <Figure size 1440x720 with 0 Axes>



    
![png](output_32_51.png)
    



    <Figure size 1440x720 with 0 Axes>



    
![png](output_32_53.png)
    


Both the number of mental hospitals, health units and outpatient facilities might have a slight positive correlation with suicide rate, it means the countries with higher suicide rate built these facilities more to handle the problems. Overall, the number of mental health facilities did not play an important role in suicide rate.


```python
# Plot the facilites sum

suicide_rates_column_sum_dataframe = suicide_rates_facilities_both_sexes_dataframe.mean()

plotting_dataframe = pd.DataFrame({"facility" : ALL_FACILITIES, "average_num" : suicide_rates_column_sum_dataframe[ALL_FACILITIES]})
print(plotting_dataframe)

#plt.figure(figsize=(20,10))
plt.barh(plotting_dataframe["facility"], plotting_dataframe["average_num"])
plt.title("Average facilities per 100,000 population")
plt.xlabel("Average number per 100,000 population")
plt.ylabel("Facility")
plt.yticks(np.arange(5), ('Residential Facilities', 'Day Treatment', 'Outpatient Facilities', 'Health Units', 'Mental Hospitals'))
plt.show()
```

                                          facility  average_num
    mental_hospitals              mental_hospitals     0.246133
    health_units                      health_units     0.296396
    outpatient_facilities    outpatient_facilities     1.728660
    day_treatment                    day_treatment     0.957612
    residential_facilities  residential_facilities     0.762909
    


    
![png](output_34_1.png)
    


The chart above shows the average of facilities of in the recorded counties. Outpatient facilities were the most built facilities to handle mental health issues while the health units and mental hospitals were the least built facilities. It is because of the purpose of the facilities were different. The outpatient facilities mainly treat the outpatients with a wide range of services while mental hospitals treat inpatients with specialities. 

### 6. Association between the availability of workforce, human resources in mental health care sectors and suicide rates in countries:

Suicidal behaviours have multiple causes. The aim of this analysis is to investigate the influence of mental health professional availability over the suicide. The hypothesis here is that the countries which have more mental health care services have lower suicide rate.

The data is based on 2016 suicide rate data and human resource data in availability of psychiatrists, psychologists and nurses in mental healthcare sector in the countries in the world. Each observation represents the number of suicides in each country in Y-axis and health care staff count in X-axis. The figures are per 100,000 population.


```python
# ========= Prepare Data =========
# Load Human Resource data
hr_data = data_reader.read_data(SuicideRawData.HUMAN_RESOURCES)

# Filter the suicide rate data with columns - country, all_age and sex only
suicide_rate_dataframe = suicide_rate_data[["country", "all_age", "sex"]]
#suicide_rate_dataframe

# Merge the two dataframes for plotting purpose
merged_dataframe = pd.merge(suicide_rate_dataframe, hr_data, on="country")
merged_dataframe.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>country</th>
      <th>all_age</th>
      <th>sex</th>
      <th>year</th>
      <th>psychiatrists</th>
      <th>nurses</th>
      <th>social_workers</th>
      <th>psychologists</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Afghanistan</td>
      <td>93.2</td>
      <td>Both sexes</td>
      <td>2016</td>
      <td>0.231</td>
      <td>0.098</td>
      <td>NaN</td>
      <td>0.296</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Afghanistan</td>
      <td>157.1</td>
      <td>Male</td>
      <td>2016</td>
      <td>0.231</td>
      <td>0.098</td>
      <td>NaN</td>
      <td>0.296</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Afghanistan</td>
      <td>35.1</td>
      <td>Female</td>
      <td>2016</td>
      <td>0.231</td>
      <td>0.098</td>
      <td>NaN</td>
      <td>0.296</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Albania</td>
      <td>65.1</td>
      <td>Both sexes</td>
      <td>2016</td>
      <td>1.471</td>
      <td>6.876</td>
      <td>1.06</td>
      <td>1.231</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Albania</td>
      <td>86.3</td>
      <td>Male</td>
      <td>2016</td>
      <td>1.471</td>
      <td>6.876</td>
      <td>1.06</td>
      <td>1.231</td>
    </tr>
  </tbody>
</table>
</div>




```python
# ========= Plotting (1) =========
#Plotting to visualise the association between Suicide rate of All age and Psychiatrists

# setting style
sns.set_style("darkgrid", {"axes.facecolor": ".9"})

# https://seaborn.pydata.org/tutorial/aesthetics.html
# https://seaborn.pydata.org/generated/seaborn.lmplot.html

plot_psy = sns.lmplot(data= merged_dataframe, x="psychiatrists", y= "all_age", palette="Set1", col="sex", hue="sex")
plot_psy.set_axis_labels("Psychiatrists", "Suicide Rate in All age")

# This is to adjust the axis and display the main title
# without it, seaborn"s facet titles and the main title are overlapped
plt.subplots_adjust(top=0.85)
plot_psy.fig.suptitle("Global Psychiatrists Availability Vs Suicide Rate \n in 2016 per 100,000 population")
plt.show()
```


    
![png](output_38_0.png)
    



```python
# ========= Plotting (2) =========
# Plotting to to see the association between Suicide rate of All age and Nurses among Sexes

plot_nurses = sns.lmplot(data= merged_dataframe, x="nurses", y= "all_age", palette="Set1", col="sex", hue="sex") 
plot_nurses.set_axis_labels("Nurses per 100,000 population", "Suicide Rate in All Ages")

# This is to adjust the axis and display the main title
# without it, seaborn"s facet titles and the main title are overlapped
plt.subplots_adjust(top=0.85)
plot_nurses.fig.suptitle("World Nurses Availability Vs Suicide Rate in 2016 \n in 2016 per 100,000 population")

plt.show()
```


    
![png](output_39_0.png)
    


Firstly, in reading about HR, the Plots show there are less than 25 psychologists, psychiatrists and nurses in most of the countries.  All the observations are cluttered on x-axis from 0 to 25 in all the plots. Only 5 countries have 50 psychologists and above. Among the three groups of staff, the psychiatrists are less common than the other two, the scale of its x-axis shows only up to 50 while psychologists and nurses have over 200 and 150 respectively.

Secondly, in reading about suicide rate alone, it is below 200 in both male and female in majority of the countries.
With regards to the association, most of the countries with high suicide rate above 100 have very minimum availability of the mental health care professionals of less than 50. At the same time, there are some countries with nurses and psychologists below 25 also have low suicide rate below 100. It is not very clear to define the strength of the association between the suicide rate and HR availability and our hypothesis has turned out untrue.

The regression line for Female in the three plots and Male in the plot(a) highlights a slight positive correlation. The more psychologists are employed, the less chance of suicide in the countries. However, it is not the case for Male with the availability of nurses and psychiatrists. The regression line of suicide rate continues to take upward trend.
